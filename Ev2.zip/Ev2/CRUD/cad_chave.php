<?php
    require('../conn.php');

    $sala = $_POST['sala'];
   
    if(empty($sala)){
        echo "Os valores não podem ser vazios";
    } else {
        $cad_chave = $pdo->prepare("INSERT INTO chave(sala) VALUES(:sala)");
        $cad_chave->execute(array(
            ':sala'=> $sala
        ));

        // PHP code to set a flag or message for successful insertion
        $success = true;
    }
?>

<?php if(isset($success) && $success): ?>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script>
        swal({
            title: "Sucesso!",
            text: "Chave Cadastrada com Sucesso! :)",
            icon: "success",
            button: "Aww yiss!"
        });
    </script>
<?php endif; ?>