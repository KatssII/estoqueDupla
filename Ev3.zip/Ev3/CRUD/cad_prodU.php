<?php
    require('../conn.php');

    $dataEntradaU = $_POST['dataEntradaU'];
    $materialU = $_POST['materialU'];
    $unidadeU = $_POST['unidadeU'];
    $quantidadeU = $_POST['quantidadeU'];
    $fornecedorU = $_POST['fornecedorU'];
    $categoriaU = $_POST['categoriaU'];
   
    if(empty($dataEntradaU) || empty($materialU) || empty($unidadeU) || empty($quantidadeU) || empty($fornecedorU) || empty($categoriaU)){
        echo "Os valores não podem ser vazios";
    }else{
        $cad_prodU = $pdo->prepare("INSERT INTO prod_unico(dataEntradaU, materialU, unidadeU, quantidadeU, fornecedorU, categoriaU) 
        VALUES(:dataEntradaU, :materialU, :unidadeU, :quantidadeU, :fornecedorU, :categoriaU)");
        $cad_prodU->execute(array(
            ':dataEntradaU'=> $dataEntradaU,
            ':materialU'=> $materialU,
            ':unidadeU'=> $unidadeU,
            ':quantidadeU'=> $quantidadeU,
            ':fornecedorU'=> $fornecedorU,
             ':categoriaU'=> $categoriaU    
        ));

        echo "<script>
        alert('Item Cadastrada com sucesso!');
        </script>";
    }
?>